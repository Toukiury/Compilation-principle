#pragma once

#include "ir_opt/ir_core.hpp"
#include "ast/ast_visitor.hpp"
#include "ast/ast_stmt.hpp"

#include <fstream>
#include <memory>
#include <vector>
#include <map>
#include <string>


namespace ir {

    /**
     * @brief 作用域类
     * 
    */
    class Scope {
    public:
        // 进入一个新的作用域
        void enter();
    
        // 进入循环作用域
        void enter_loop(std::weak_ptr<BasicBlock> cond,std::weak_ptr<BasicBlock> body_bb, 
            std::weak_ptr<BasicBlock> brk_bb, bool is_while_stmt);
    
        // 获取循环作用域的循环体
        std::weak_ptr<BasicBlock> get_loop_body();
    
        // 获取循环作用域的循环跳出
        std::weak_ptr<BasicBlock> get_loop_brk();
    
        // 获取循环作用域的循环条件
        std::weak_ptr<BasicBlock> get_loop_cond();
    
        // 检测是否在循环作用域
        bool is_in_loop() { 
            return loop_cond_stack_.size() > 0;
        }
    
        // 离开循环作用域
        void leave_loop();
    
        // 离开一个作用域
        void leave();
    
        // 检测是否在全局作用域
        bool is_global();
    
        bool is_while_stmt() {
            return is_while_stmt_;
        }
    
        // 加入一个符号
        void push(const std::string &name, std::shared_ptr<Value> value);
    
        // 查找一个符号
        std::shared_ptr<Value> find(const std::string &name);
    
        // 当前作用域的函数
        std::shared_ptr<Function> current_f_ = nullptr;
    
        // 打印作用域的符号
        void print();
    
        void dumpToFile(const std::string &filename);
    private:
        // 栈式存储分配
        // 是一个 vector, 每个元素相当于作用域 map, 作用域 map 中存储了当前作用域的符号
        std::vector<std::map<std::string, std::shared_ptr<Value>>> symbols_;
    
        // 循环栈
        std::vector<std::weak_ptr<BasicBlock>> loop_cond_stack_;
        std::vector<std::weak_ptr<BasicBlock>> loop_body_stack_;
        std::vector<std::weak_ptr<BasicBlock>> loop_brk_stack_;
        bool is_while_stmt_ = false;
    };
    
    
    /**
     * @brief 中间代码生成器
     * 继承 StmtVisitor, 生成中间代码
    */
    class IRGenerator : public StmtVisitor {
    public:
        // 语句访问者
        void visit(ExprStmt &stmt) override;
        void visit(RelExprStmt &stmt) override;
        void visit(AddExprStmt &stmt) override;
        void visit(MulExprStmt &stmt) override;
        void visit(UnaryExprStmt &stmt) override;
        void visit(PrimaryExprStmt &stmt) override;
        void visit(ValueStmt &stmt) override;
        void visit(NumberStmt &stmt) override;
        void visit(StrStmt &stmt) override;
        void visit(LValStmt &stmt) override;
        void visit(FuncCallStmt &stmt) override;
        void visit(PeriodStmt &stmt) override;
        void visit(ConstDeclStmt &stmt) override;
        void visit(VarDeclStmt &stmt) override;
        void visit(FuncHeadDeclStmt &stmt) override;
        void visit(FuncBodyDeclStmt &stmt) override;
        void visit(FuncDeclStmt &stmt) override;
        void visit(AssignStmt &stmt) override;
        void visit(IfStmt &stmt) override;
        void visit(ForStmt &stmt) override;
        void visit(WhileStmt &stmt) override;
        void visit(ReadFuncStmt &stmt) override;
        void visit(WriteFuncStmt &stmt) override;
        void visit(BreakStmt &stmt) override;
        void visit(ContinueStmt &stmt) override;
        void visit(ProgramHeadStmt &stmt) override;
        void visit(ProgramBodyStmt &stmt) override;
        void visit(ProgramStmt &stmt) override;
        void dumpIRToFile(const std::string& filename);
         
    
        Module get_ir() { return module_; }
    
        Scope scope_; // 作用域
        Module module_; // 中间代码
    
        void show_result(std::ofstream &out) {
            // 保存原始的 cout buffer
            std::streambuf* oldCoutStreamBuf = std::cout.rdbuf();
            // 重定向 cout 到文件
    
    
            std::cout.rdbuf(out.rdbuf());
            std::cout << "The global identifiers are as follows:" << "\n";
    
            for (const auto &global : module_.global_identifiers_) {
                if (global->is_const_) {
                    std::cout << "const " + global->type_->print() << " " << global->name_ << " = " << global->init_val_->print() << "\n";
                } else {
                    std::string s = global->type_->print();
                    int ps = s.find(" ");
                    if (ps == std::string::npos) {
                        std::cout << global->type_->print() << " " << global->name_ << "\n";
                    } else {
                        std::cout << s.substr(0, ps) << " " << global->name_ << s.substr(ps + 1) << "\n";
                    }
                }
            }
            // 外层遍历函数
            std::cout << "----------------------------------------------------------------------------------------------------------" << "\n";
            for (int i = 0; i < module_.functions_.size(); i++) {
                std::weak_ptr<Function> func = module_.functions_[i];
                std::cout << "The " << i + 1  << " function information is as follows：" << "\n";
                std::cout << "Function header：" << func.lock()->print() << "\n";
                std::cout << "The local identifiers are as follows:" << "\n";
                for (const auto &local : func.lock()->local_identifiers_) {
                    if (local->is_const_) {
                        std::cout << local->type_->print() << " " << local->name_ << " = " << local->init_val_->print() << "\n";
                    } else {
                        std::cout << local->type_->print() << " " << local->name_ << "\n";
                    }
                }
                std::cout << "The basic blocks are as follows:" << "\n";
                std::cout << "\n";
                std::map<BasicBlock *, int> bb_map;
                for (int j = 0; j < func.lock()->basic_blocks_.size(); j++) {
                    bb_map[func.lock()->basic_blocks_[j].get()] = j + 1;
                }
                for (int j = 0; j < func.lock()->basic_blocks_.size(); j++) {
                    std::shared_ptr<BasicBlock> bb = func.lock()->basic_blocks_[j];
                    std::cout << "The " << j + 1 << " basic block is as follows：" << "\n";
                    std::cout << "Base block name：" << bb->name_ << "\n";
                    std::cout << "The list of instructions is as follows：" << "\n";
                    for (int k = 0; k < bb->instructions_.size(); k++) {
                        std::shared_ptr<Instruction> inst = bb->instructions_[k];
                        std::cout << "\t" << inst->print() << "\n";
                    }
                    std::cout << "\n\n";
                    std::cout << "The basic blocks of the precursor are as follows" << "\n";
                    for(auto &tmp: bb->pre_bbs_) {
                        std::cout << bb_map[tmp.lock().get()] << " ";
                    }
                    std::cout << "\n";
                    std::cout << "The successor basic blocks are as follows" << "\n";
                    for(auto &tmp: bb->succ_bbs_) {
                        std::cout << bb_map[tmp.lock().get()] << " ";
                    }
                    std::cout << "\n";
                }
                
                std::cout << "----------------------------------------------------------------------------------------------------------" << "\n";
            }
            // 恢复原始的 cout buffer
            std::cout.rdbuf(oldCoutStreamBuf);
    
        
        }
        
        IRGenerator() {
            // 进入全局作用域
            scope_.enter();
        }
         // 新增可视化方法
    };
    
    
    
    } // namespace ir
